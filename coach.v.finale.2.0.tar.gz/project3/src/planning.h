#include <gtk/gtk.h>

typedef struct
{

char p[20];
char jour[20];
char heure[30];


}plan;

void ajou_planning(plan d);
void afficher_planning(GtkWidget *list);
