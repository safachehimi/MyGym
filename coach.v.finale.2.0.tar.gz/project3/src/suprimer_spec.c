#include "suprimer_spec.h"


void sup_speci(char a[20])// parametre entrer en chercher pour la supprimer
{	char s[10];
	FILE *l;
	FILE *t;
	l=fopen("specialitee.txt","r");
	t=fopen("specialitee.tmp","a+");
	if(l!=NULL)
	{
	while (fscanf(l,"%s	\n",s)!=EOF)
	{if (strcmp(a,s)!=0)
		{fprintf(t,"%s 	\n",s);}
	}
	fclose(l);
	fclose(t);
	}


	remove("specialitee.txt");//supprimer fichier ancien
	rename("specialitee.tmp","specialitee.txt");//renommer fichier nouveau pour enfin avoir un seul fichier
}
