#include "suprimer_disp.h"
#include "Disponibilite.h"


void sup_dispo(char a[20])// a le  parametre a supprimer 
{
	dispo p;

	FILE *l;
	FILE *t;
	l=fopen("Disponibilite.txt","r");
	t=fopen("Disponibilite.tmp","a+");
	while (fscanf(l,"%s %s %s ",p.jour,p.debut,p.fin)!=EOF)//
	{
		if (strcmp(a,p.jour)!=0)//seulmlnt pour a different des a1 on copie les lignes diff 
		{
			fprintf(t,"%s %s %s\n",p.jour,p.debut,p.fin);//copie  la ligne dans le fichier .tmp
	}
	fclose(l);
	fclose(t);
	remove("Disponibilite.txt");//effacer fichier ancien
	rename("Disponibilite.tmp","Disponibilite.txt");//rennomer 
}}
