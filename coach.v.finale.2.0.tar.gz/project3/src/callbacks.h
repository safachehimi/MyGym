#include <gtk/gtk.h>

void
on_c1_clicked                     (GtkWidget *widget, gpointer user_data);

void
on_c2_clicked                     (GtkWidget *widget, gpointer user_data);

void
on_c3_clicked                     (GtkWidget *widget, gpointer user_data);

void
on_c4_clicked                     (GtkWidget *widget, gpointer user_data);

void
on_c5_clicked                     (GtkWidget *widget, gpointer user_data);

void
on_c6_clicked                     (GtkWidget *widget, gpointer user_data);

void
on_c7_clicked                     (GtkWidget *widget, gpointer user_data);

void
on_c8_clicked                     (GtkWidget *widget, gpointer user_data);

void
on_c9_clicked                     (GtkWidget *objet, gpointer user_data);

void
on_c10_clicked                    (GtkWidget *widget, gpointer user_data);

void
on_c11_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c12_clicked                    (GtkWidget *widget, gpointer user_data);

void
on_c13_clicked                    (GtkWidget *widget, gpointer user_data);

void
on_c15_clicked                    (GtkWidget *widget, gpointer user_data);

void
on_c16_clicked                    (GtkWidget *widget, gpointer user_data);

void
on_c17_clicked                    (GtkWidget *widget, gpointer user_data);

void
on_c18_clicked                    (GtkWidget *widget, gpointer user_data);

void
on_c19_clicked                    (GtkWidget *widget, gpointer user_data);

void
on_c20_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c21_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c22_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c23_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c24_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c25_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c26_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c27_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c28_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c29_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c30_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c31_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c32_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c34_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_c33_clicked                         (GtkWidget *widget, gpointer user_data);

void
on_button_refresh_coach_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_refresh_planning_clicked     (GtkButton       *button,
                                        gpointer         user_data);
