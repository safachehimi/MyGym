#include <gtk/gtk.h>

typedef struct
{

char jour[20];
char debut[20];
char fin[30];


}dispon;

void modif_dispo(dispon p);
